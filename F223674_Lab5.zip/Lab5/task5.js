$("#city").click(function () {
    $("body").css({'background-image': 'url(./city.jpg)', 'background-size' : 'cover', 'background-repeat' : 'no-repeat'})
})
$("#ocean").click(function () {
    $("body").css({'background-image': 'url(./ocean.jpg)', 'background-size' : 'cover', 'background-repeat' : 'no-repeat'})
})
$("#nature").click(function () {
    $("body").css({'background-image': 'url(./nature.jpg)', 'background-size' : 'cover', 'background-repeat' : 'no-repeat'})
})