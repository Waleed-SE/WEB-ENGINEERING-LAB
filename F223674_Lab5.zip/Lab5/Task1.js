$("#button-toggle").click(function() {
    $("#toggle").toggle();
})