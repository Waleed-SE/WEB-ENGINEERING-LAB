function handleSubmit(event) {
    event.preventDefault();
    alert("Form Submitted Successfully!");
    document.getElementById("contactForm").reset();
}